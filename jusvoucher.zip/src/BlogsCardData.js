import CardImage01 from "./components/asset/blog-Card-01.jpg";
import CardImage02 from "./components/asset/blog-Card-02.jpg";
import CardImage03 from "./components/asset/blog-Card-03.jpg";
import CardImage04 from "./components/asset/blog-Card-04.jpg";
import CardImage05 from "./components/asset/blog-Card-05.jpg";
import CardImage06 from "./components/asset/blog-Card-06.jpg";

const Data = [
  {
    image: CardImage01,
    Date: "22-March-2022",
    Name: "Mathew Hayden",
    Title: "Velusche Nomadism",
    Description:
      " Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi sit quas fugit perferendis nemo expedita soluta odio praesentium consequatur enim, ullam provident facere maxime perspiciatis,quam neque magnam, similique eius?",

    Tagline:
      "  Integer lacinia sollicitudin massa. Cras metus. Sed aliquet risusa tortor. Integer id quam. Morbi mi. Quisque nisl felis, venenatis tristique, dignissim in, ultrices sit amet, augue. Proin sodales libero eget ante.",
  },
  {
    image: CardImage02,
    Date: "22-March-2022",
    Title: "Velusche Nomadism",
    Description:
      " Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi sit quas fugit perferendis nemo expedita soluta odio praesentium consequatur enim, ullam provident facere maxime perspiciatis,quam neque magnam, similique eius?",
  },
  {
    image: CardImage03,
    Date: "22-March-2022",
    Title: "Velusche Nomadism",
    Description:
      " Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi sit quas fugit perferendis nemo expedita soluta odio praesentium consequatur enim, ullam provident facere maxime perspiciatis,quam neque magnam, similique eius?",
  },
  {
    image: CardImage04,
    Date: "22-March-2022",
    Title: "Velusche Nomadism",
    Description:
      " Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi sit quas fugit perferendis nemo expedita soluta odio praesentium consequatur enim, ullam provident facere maxime perspiciatis,quam neque magnam, similique eius?",
  },
  {
    image: CardImage05,
    Date: "22-March-2022",
    Title: "Velusche Nomadism",
    Description:
      " Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi sit quas fugit perferendis nemo expedita soluta odio praesentium consequatur enim, ullam provident facere maxime perspiciatis,quam neque magnam, similique eius?",
  },
  {
    image: CardImage06,
    Date: "22-March-2022",
    Title: "Velusche Nomadism",
    Description:
      " Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi sit quas fugit perferendis nemo expedita soluta odio praesentium consequatur enim, ullam provident facere maxime perspiciatis,quam neque magnam, similique eius?",
  },
];
export default Data;
