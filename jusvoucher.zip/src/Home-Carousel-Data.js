import Card01 from "./components/asset/Card 01.svg";
import Card02 from "./components/asset/Card 02.svg";
import Card03 from "./components/asset/Card 03.svg";
import Card04 from "./components/asset/Card 04.svg";
import Card05 from "./components/asset/Card 05.svg";
import Card06 from "./components/asset/Card 06.svg";
import Card07 from "./components/asset/Card 07.svg";
const Data = [
  {
    image: Card01,
  },
  {
    image: Card02,
  },
  {
    image: Card03,
  },
  {
    image: Card04,
  },
  {
    image: Card05,
  },
  {
    image: Card06,
  },
  {
    image: Card07,
  },
];
export default Data;
