import Card01 from './components/asset/Card-1.webp'
import Card02 from './components/asset/Card-2.webp'
import Card03 from './components/asset/Card-3.webp'
import Card04 from './components/asset/Card-4.png'
import Card05 from './components/asset/Card-5.webp'
import Card06 from './components/asset/Card-6.webp'
import Card07 from './components/asset/Card-7.png'
const Data = [
  {
    image: Card01,
  },
  {
    image: Card02,
  },
  {
    image: Card03,
  },
  {
    image: Card04,
  },
  {
    image: Card05,
  },
  {
    image: Card06,
  },
  {
    image: Card07,
  },
];
export default Data;
